/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */




import com.mycompany.project.healthRecord;
import com.mycompany.project.HealthManager;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class RecordScreen extends JFrame{
    




    public RecordScreen() {

        setTitle("Report");
        setSize(400, 300);

        JTextArea area = new JTextArea();
        JScrollPane sp = new JScrollPane(area);

        StringBuilder sb = new StringBuilder();

        for (healthRecord r : new HealthManager().getAll()) {
            sb.append(r.getDate())
              .append(" | Steps: ")
              .append(r.getSteps())
              .append("\n");
        }

        area.setText(sb.toString());

        add(sp);

        setVisible(true);
    }

}
