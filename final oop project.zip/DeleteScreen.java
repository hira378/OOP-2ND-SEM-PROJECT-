/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */

import javax.swing.*;
import java.awt.*;
public class DeleteScreen extends JFrame {
    



    public DeleteScreen() {

        setTitle("Delete Record");
        setSize(300,150);
        setLayout(new FlowLayout());

        JTextField t = new JTextField(15);
        JButton b = new JButton("Delete");

        add(new JLabel("Enter Date:"));
        add(t);
        add(b);

        b.addActionListener(e -> {
            new HealthManager().delete(t.getText());
            JOptionPane.showMessageDialog(this,"Record Deleted");
        });

        setVisible(true);
    }

    
}
