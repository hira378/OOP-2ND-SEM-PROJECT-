/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */
import javax.swing.*;
import java.awt.*;

public class UpdateScreen extends JFrame {
   
    public UpdateScreen() {

        setTitle("Update Record");
        setSize(300,300);
        setLayout(new GridLayout(5,2));

        JTextField oldDate = new JTextField();
        JTextField newDate = new JTextField();
        JTextField w = new JTextField();
        JTextField s = new JTextField();
        JTextField sl = new JTextField();

        JButton btn = new JButton("Update");

        add(new JLabel("Old Date")); add(oldDate);
        add(new JLabel("New Date")); add(newDate);
        add(new JLabel("Water")); add(w);
        add(new JLabel("Steps")); add(s);
        add(new JLabel("Sleep")); add(sl);
        add(btn);

        btn.addActionListener(e -> {
            try {
                healthRecord r = new healthRecord(
                        newDate.getText(),
                        Integer.parseInt(w.getText()),
                        Integer.parseInt(s.getText()),
                        Integer.parseInt(sl.getText())
                );

                new HealthManager().update(oldDate.getText(), r);

                JOptionPane.showMessageDialog(this,"Record Updated");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,"Invalid Input");
            }
        });

        setVisible(true);
    }

}
