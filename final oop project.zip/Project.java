/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project;

/**
 *
 * @author hp
 */


public class Project {

    public static void main(String[] args) {
        


    
        new Dashboard();
    }
}
    

