/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */




import java.util.*;
import java.util.*;
public class HealthManager {
    





    public void add(healthRecord r) {
        fileManager.save(r);
    }

    public List<healthRecord> getAll() {
        return fileManager.load();
    }

    public void delete(String date) {
        List<healthRecord> list = getAll();
        list.removeIf(r -> r.getDate().equals(date));
        fileManager.overwrite(list);
    }

    public healthRecord search(String date) {
        for (healthRecord r : getAll()) {
            if (r.getDate().equals(date)) return r;
        }
        return null;
    }

    public void update(String date, healthRecord newRecord) {
        List<healthRecord> list = getAll();

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getDate().equals(date)) {
                list.set(i, newRecord);
                break;
            }
        }

        fileManager.overwrite(list);
    }
}
