/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */

import javax.swing.*;
import java.awt.*;
public class SearchScreen extends JFrame {

    public SearchScreen() {

        setTitle("Search Record");
        setSize(300,200);
        setLayout(new FlowLayout());

        JTextField t = new JTextField(15);
        JTextArea res = new JTextArea(5,20);

        JButton b = new JButton("Search");

        add(new JLabel("Enter Date:"));
        add(t);
        add(b);
        add(res);

        b.addActionListener(e -> {
            healthRecord r = new HealthManager().search(t.getText());

            if (r != null) {
                res.setText(
                    "Date: " + r.getDate() +
                    "\nWater: " + r.getWater() +
                    "\nSteps: " + r.getSteps() +
                    "\nSleep: " + r.getSleep()
                );
            } else {
                res.setText("Record Not Found");
            }
        });

        setVisible(true);
    }

}
