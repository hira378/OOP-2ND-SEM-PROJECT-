/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */

import java.io.*;
import java.util.*;
public class fileManager {
 

    private static final String FILE = "data.txt";

    public static void save(healthRecord r) {
        try (FileWriter fw = new FileWriter(FILE, true)) {
            fw.write(r.toFileString() + "\n");
        } catch (Exception e) {}
    }

    public static List<healthRecord> load() {
        List<healthRecord> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(healthRecord.fromString(line));
            }
        } catch (Exception e) {}
        return list;
    }

    public static void overwrite(List<healthRecord> list) {
        try (FileWriter fw = new FileWriter(FILE)) {
            for (healthRecord r : list) {
                fw.write(r.toFileString() + "\n");
            }
        } catch (Exception e) {}
    }
}

  



