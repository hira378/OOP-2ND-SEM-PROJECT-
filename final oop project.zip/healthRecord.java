/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */
public class healthRecord {
    
    

    private String date;
    private int water, steps, sleep;

    public healthRecord(String date, int water, int steps, int sleep) {
        this.date = date;
        this.water = water;
        this.steps = steps;
        this.sleep = sleep;
    }

    public String getDate() { return date; }
    public int getWater() { return water; }
    public int getSteps() { return steps; }
    public int getSleep() { return sleep; }

    public String toFileString() {
        return date + "," + water + "," + steps + "," + sleep;
    }

    public static healthRecord fromString(String line) {
        String[] p = line.split(",");
        return new healthRecord(
                p[0],
                Integer.parseInt(p[1]),
                Integer.parseInt(p[2]),
                Integer.parseInt(p[3])
        );
    }
}

