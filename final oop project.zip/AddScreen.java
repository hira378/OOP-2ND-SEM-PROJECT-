/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */
 

import javax.swing.*;
import java.awt.*;
public class AddScreen extends JFrame {
   


  

    public AddScreen() {

        setTitle("Add Record");
        setSize(300,300);
        setLayout(new GridLayout(5,2));

        JTextField d = new JTextField();
        JTextField w = new JTextField();
        JTextField s = new JTextField();
        JTextField sl = new JTextField();

        JButton btn = new JButton("Save");

        add(new JLabel("Date")); add(d);
        add(new JLabel("Water")); add(w);
        add(new JLabel("Steps")); add(s);
        add(new JLabel("Sleep")); add(sl);
        add(btn);

        btn.addActionListener(e -> {
            try {

                // ✅ EMPTY CHECK
                if(d.getText().isEmpty() || w.getText().isEmpty() ||
                   s.getText().isEmpty() || sl.getText().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Fill all fields");
                    return;
                }

                healthRecord r = new healthRecord(
                        d.getText(),
                        Integer.parseInt(w.getText()),
                        Integer.parseInt(s.getText()),
                        Integer.parseInt(sl.getText())
                );

                HealthManager hm = new HealthManager();
                hm.add(r);

                JOptionPane.showMessageDialog(null,"Saved");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"Invalid Input");
            }
        });

        setVisible(true);
    }
}