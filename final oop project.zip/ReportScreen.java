/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */


import javax.swing.*;
import java.awt.*;
public class ReportScreen extends JFrame{

    public ReportScreen() {

        setTitle("Report");
        setSize(400,300);

        JTextArea area=new JTextArea();
        StringBuilder sb=new StringBuilder();

        for(healthRecord r:new HealthManager().getAll()){
            sb.append(r.getDate()+" | "+r.getSteps()+"\n");
        }

        area.setText(sb.toString());
        add(new JScrollPane(area));

        setVisible(true);
    }
}
