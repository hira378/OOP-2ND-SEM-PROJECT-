/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */
  

import javax.swing.*;
import java.awt.*;

public class Dashboard extends JFrame{
   

    public Dashboard() {

        setTitle("Health Tracker");
        setSize(400, 300);
        setLayout(new GridLayout(6,1,10,10));

        JButton add = new JButton("Add");
        JButton view = new JButton("View");
        JButton search = new JButton("Search");
        JButton delete = new JButton("Delete");
        JButton update = new JButton("Update");

        add(add); add(view); add(search); add(delete); add(update);

        add.addActionListener(e -> new AddScreen());
        view.addActionListener(e -> new ViewScreen());
        search.addActionListener(e -> new SearchScreen());
        delete.addActionListener(e -> new DeleteScreen());
        update.addActionListener(e -> new UpdateScreen());

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}