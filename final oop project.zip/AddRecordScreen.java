/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */

import com.mycompany.project.healthRecord;
import com.mycompany.project.HealthManager;

import javax.swing.*;
import java.awt.*;
public class AddRecordScreen extends JFrame{
    

    public AddRecordScreen() {

        setTitle("Old Add");
        setSize(300,300);
        setLayout(new GridLayout(5,2));

        JTextField d=new JTextField();
        JTextField w=new JTextField();
        JTextField s=new JTextField();
        JTextField sl=new JTextField();

        JButton btn=new JButton("Save");

        add(new JLabel("Date")); add(d);
        add(new JLabel("Water")); add(w);
        add(new JLabel("Steps")); add(s);
        add(new JLabel("Sleep")); add(sl);
        add(btn);

        btn.addActionListener(e->{
            healthRecord r=new healthRecord(
                    d.getText(),
                    Integer.parseInt(w.getText()),
                    Integer.parseInt(s.getText()),
                    Integer.parseInt(sl.getText())
            );
            new HealthManager().add(r);
            JOptionPane.showMessageDialog(this,"Saved");
        });

        setVisible(true);
    }
}
