/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author hp
 */
 

import javax.swing.*;
public class ViewScreen extends JFrame {
   

    public ViewScreen() {

        setTitle("View Records");
        setSize(400,300);

        JTextArea area = new JTextArea();
        StringBuilder sb = new StringBuilder();

        for (healthRecord r : new HealthManager().getAll()) {
            sb.append(r.getDate())
              .append(" | Water: ").append(r.getWater())
              .append(" | Steps: ").append(r.getSteps())
              .append(" | Sleep: ").append(r.getSleep())
              .append("\n");
        }

        area.setText(sb.toString());
        add(new JScrollPane(area));

        setVisible(true);
    }

    
}
